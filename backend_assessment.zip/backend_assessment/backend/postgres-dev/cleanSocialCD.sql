DELETE FROM "Tenant_Profile" WHERE web_url='www.cypress.com';
