DELETE FROM "Tenant" WHERE tenant_domain='cypress.com';
