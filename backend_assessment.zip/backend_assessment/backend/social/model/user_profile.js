const { Model } = require("objection");

class User_Profile extends Model {
  static get tableName() {
    return "User_Profile";
  }

  static get jsonSchema() {
    return {
      type: "object",
      properties: {
        user_id: { type: "integer" },
        first_name: { type: "string", maxLength: 255 },
        last_name: { type: "string", maxLength: 255 },
        department: { type: "string", maxLength: 255 },
        designation: { type: "string", maxLength: 255 },
        tenent_id: { type: "integer" },
        image_url: { type: "string", maxLength: 255 },
        city: { type: "string", maxLength: 255 },
        country: { type: "string", maxLength: 255 },
        bio: { type: "string", maxLength: 255 },
        social_links: { type: "object" },
        employee_id: { type: "integer" },
      },
    };
  }

  static get relationMappings() {
    return {
      tenent: {
        relation: Model.BelongsToOneRelation,
        modelClass: Tenent_Profile,
        join: {
          from: "User_Profile.tenent_id",
          to: "Tenent_Profile.tenent_id",
        },
      },
    };
  }
}

module.exports = User_Profile;
