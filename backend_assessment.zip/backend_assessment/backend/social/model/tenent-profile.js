const { Model } = require("objection");

class Tenent_Profile extends Model {
  static get tableName() {
    return "Tenent_Profile";
  }

  static get jsonSchema() {
    return {
      type: "object",
      properties: {
        tenent_id: { type: "integer" },
        tenant_name: { type: "string", maxLength: 255 },
        address: { type: "object" },
        city: { type: "string", maxLength: 255 },
        state: { type: "string", maxLength: 255 },
        country: { type: "string", maxLength: 255 },
        zip_code: { type: "string", maxLength: 255 },
        phone: { type: "string", maxLength: 255 },
        web_url: { type: "string", maxLength: 255 },
      },
    };
  }
}

module.exports = Tenent_Profile;
