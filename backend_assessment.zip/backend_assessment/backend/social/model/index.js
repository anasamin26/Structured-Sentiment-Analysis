const Tenent_Profile = require("./tenent-profile");
const User_Profile = require("./user_profile");

module.exports = {
  Tenent_Profile,
  User_Profile,
};
