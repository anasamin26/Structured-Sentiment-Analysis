const { Kafka } = require("kafkajs");
const models = require("../model");
const Tenent_Profile = models.Tenent_Profile;
const User_Profile = models.User_Profile;

const kafka = new Kafka({
  clientId: "social-service-producer",
  brokers: ["kafka:9092"],
});

const consumer = kafka.consumer({ groupId: "your-group-id" });

const startConsumer = async () => {
  await consumer.connect();
  await consumer.subscribe({ topic: "your-kafka-topic", fromBeginning: true });

  await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      const parsedMessage = JSON.parse(message.value.toString());

      if (topic === "tenent_profile_topic") {
        try {
          await Tenent_Profile.query().insert(parsedMessage);
        } catch (error) {
          console.error("Error inserting into Tenent_Profile:", error);
        }
      } else if (topic === "user_profile_topic") {
        try {
          await User_Profile.query().insert(parsedMessage);
        } catch (error) {
          console.error("Error inserting into User_Profile:", error);
        }
      } else {
        console.warn("Unknown topic:", topic);
      }
    },
  });
};

module.exports = { startConsumer };
