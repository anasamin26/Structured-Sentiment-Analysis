const { Model } = require("objection");
const Knex = require("knex");
const dbConfig = require("./dbConfig");

const initializeDB = async () => {
  const knex = Knex({
    client: "pg",
    connection: {
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.username,
      password: dbConfig.password,
      database: dbConfig.database,
    },
  });

  Model.knex(knex);
};

module.exports = {
  initializeDB,
};
