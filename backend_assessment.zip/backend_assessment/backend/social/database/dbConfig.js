const dbConfig = {
  port: 5432,
  host: "postgres", // Hostname of your PostgreSQL service
  username: process.env.POSTGRES_USERNAME,
  password: process.env.POSTGRES_PASSWORD,
  database: process.env.POSTGRES_DATABASE,
};

module.exports = dbConfig;
