const express = require("express");
// const { initConsumer } = require("./utilities/consumer");
const { initProducer } = require("./utilities/producer");
// const { connectConsumer } = require("./utilities/consumer");
// const { connectProducer, connectAdmin } = require("./utilities/producer");
// const KeyMaster = require("./utilities/KeyMaster");
const databaseConfig = require("./database/DatabaseConfig");
const models = require("./model");
const Tenent_Profile = models.Tenent_Profile;
const User_Profile = models.User_Profile;
const app = express();

const startApp = async () => {
  try {
    await databaseConfig.initializeDB();
    await Promise.all([
      models.User_Profile.query().schema.createTable(),
      models.Tenent_Profile.query().schema.createTable(),
    ]);
    console.log("Models synced with the database.");
  } catch (error) {
    console.error("Error syncing models:", error);
  }
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  const tenentProfileRouter = express.Router();

  tenentProfileRouter.post("/api/tenent_profile", async (req, res) => {
    const data = req.body;
    try {
      const tenentProfile = await Tenent_Profile.query().insert(data);
      res.status(201).json(tenentProfile);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  tenentProfileRouter.get("/api/tenent_profile", async (req, res) => {
    try {
      const tenentProfiles = await Tenent_Profile.query();
      res.json(tenentProfiles);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  tenentProfileRouter.get("/api/tenent_profile/:id", async (req, res) => {
    const id = req.params.id;
    try {
      const tenentProfile = await Tenent_Profile.query().findById(id);
      if (tenentProfile) {
        res.json(tenentProfile);
      } else {
        res.status(404).json({ message: "Tenent_Profile not found" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  tenentProfileRouter.delete("/api/tenent_profile/:id", async (req, res) => {
    const id = req.params.id;
    try {
      const deletedCount = await Tenent_Profile.query().deleteById(id);
      if (deletedCount === 1) {
        res.json({ message: "Tenent_Profile deleted successfully" });
      } else {
        res.status(404).json({ message: "Tenent_Profile not found" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  tenentProfileRouter.patch("/api/tenent_profile/:id", async (req, res) => {
    const id = req.params.id;
    const data = req.body;
    try {
      const updatedTenentProfile =
        await Tenent_Profile.query().patchAndFetchById(id, data);
      if (updatedTenentProfile) {
        res.json(updatedTenentProfile);
      } else {
        res.status(404).json({ message: "Tenent_Profile not found" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  const userProfileRouter = express.Router();

  userProfileRouter.post("/api/user_profile", async (req, res) => {
    const data = req.body;
    try {
      const userProfile = await User_Profile.query().insert(data);
      res.status(201).json(userProfile);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  userProfileRouter.get("/api/user_profile", async (req, res) => {
    try {
      const userProfiles = await User_Profile.query();
      res.json(userProfiles);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  userProfileRouter.get("/api/user_profile/:id", async (req, res) => {
    const id = req.params.id;
    try {
      const userProfile = await User_Profile.query().findById(id);
      if (userProfile) {
        res.json(userProfile);
      } else {
        res.status(404).json({ message: "User_Profile not found" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  userProfileRouter.delete("/api/user_profile/:id", async (req, res) => {
    const id = req.params.id;
    try {
      const deletedCount = await User_Profile.query().deleteById(id);
      if (deletedCount === 1) {
        res.json({ message: "User_Profile deleted successfully" });
      } else {
        res.status(404).json({ message: "User_Profile not found" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  userProfileRouter.patch("/api/user_profile/:id", async (req, res) => {
    const id = req.params.id;
    const data = req.body;
    try {
      const updatedUserProfile = await User_Profile.query().patchAndFetchById(
        id,
        data
      );
      if (updatedUserProfile) {
        res.json(updatedUserProfile);
      } else {
        res.status(404).json({ message: "User_Profile not found" });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  app.use("/", async (req, res) => {
    res
      .status(200)
      .json({ message: `App is running on port. ${process.env.PORT || 4000}` });
  });

  app.listen(process.env.PORT || 4000, async () => {
    console.log("App started at port", process.env.PORT || 4000);
    await initProducer();
  });
};
startApp();
